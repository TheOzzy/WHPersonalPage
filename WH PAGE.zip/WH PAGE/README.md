# WHPersonalPage
Here will be my personal blog page. So far from the time this has been last updated this the page hasn't had much improvements it's only been coded in HTML with CSS and JavaScript being added in future. - 22/09/20

#WHPersonalPage Updates 1.0
CSS Styling is now being applied changes to background colour and design will now begin, this is only to affect small cosmetic changes to the website
